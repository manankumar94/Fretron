import java.util.*;

public class Problem_1 {
    public static void main(String[] args) {
        List<int[][]> flights = new ArrayList<>();

        flights.add(new int[][]{{1, 1}, {2, 3}, {3, 4}});
        flights.add(new int[][]{{4, 5}, {6, 7}, {8, 9}});
        flights.add(new int[][]{{10, 11}, {12, 13}, {14, 15}});

        
        change_karo_Sabko(flights);

        System.out.println("\nNaye Raste:");
        for (int i = 0; i < flights.size(); i++) {
            System.out.print("Flight " + (i + 1) + ": ");
            kalakari(flights.get(i));
        }
    }

    private static void kalakari(int[][] path) {
        for (int[] coord : path) {
            System.out.print("(" + coord[0] + ", " + coord[1] + ") ");
        }
        System.out.println();
    }

    private static void change_karo_Sabko(List<int[][]> flights) {
        for (int i = 1; i < flights.size(); i++) {
            int[][] path = flights.get(i);
            for (int j = 0; j < path.length; j++) {
                path[j][0] += i;
                path[j][1] += i;
            }
        }
    }
}
