import java.util.*;

public class Problem_2 {
    public static void main(String[] args) {
        List<Integer> weight = new ArrayList<>();
        Scanner z = new Scanner(System.in);
        long totalWeight = 0;
        int a = 0;
        while (a != -1) {
            System.out.print("Enter apple weight in gram (-1 to stop ): ");
            a = z.nextInt();
            if (a != -1) {
                totalWeight += a;
                weight.add(a);
            }
        }

        System.out.println("Total Weight: " + totalWeight);

        Collections.sort(weight, Collections.reverseOrder());

        int totalMoney = 100;
        int ramMoney = 50;
        int shamMoney = 30;
        int rahimMoney = 20;

        double ram_ka_hissa = (double) ramMoney / totalMoney;
        double sham_ka_hissa = (double) shamMoney / totalMoney;
        double rahim_ka_hissa = (double) rahimMoney / totalMoney;


        int ram_weight = (int) Math.round(totalWeight * ram_ka_hissa);
        int sham_weight = (int) Math.round(totalWeight * sham_ka_hissa);
        int rahim_weight = (int) Math.round(totalWeight * rahim_ka_hissa);


        int ramTotalWeight = 0;
        int shamTotalWeight = 0;
        int rahimTotalWeight = 0;

        List<Integer> ramApples = new ArrayList<>();
        List<Integer> shamApples = new ArrayList<>();
        List<Integer> rahimApples = new ArrayList<>();

        for (int i = 0; i < weight.size(); i++) {
            int currentAppleWeight = weight.get(i);
            if (ramTotalWeight + currentAppleWeight <= ram_weight) {
                ramTotalWeight += currentAppleWeight;
                ramApples.add(currentAppleWeight);
            } else if (shamTotalWeight + currentAppleWeight <= sham_weight) {
                shamTotalWeight += currentAppleWeight;
                shamApples.add(currentAppleWeight);
            } else {
                rahimTotalWeight += currentAppleWeight;
                rahimApples.add(currentAppleWeight);
            }
        }

        System.out.println("Distribution Result:");
        System.out.println("Ram: " + ramApples);
        System.out.println("Sham: " + shamApples);
        System.out.println("Rahim: " + rahimApples);
    }
}
